<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body class="bg-body-pattern bg-scroll">
<header id="header" class="bg-black font-sans text-white h-20">
    <div class="container mx-auto flex flex-row">
        <div id="logo" class="flex-auto">
            <span class="web-symbol">S</span>
            <h3>Logo</h3>
        </div>
        <div class="flex-1">
            <?php $__env->startSection('header'); ?>
                es el encabezado
            <?php echo $__env->yieldSection(); ?>
        </div>
        
        <?php echo $__env->make('includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</header><?php /**PATH C:\laragon\www\TercerParcial\resources\views/includes/header.blade.php ENDPATH**/ ?>