<?php use App\Http\Controllers\lentes_controller;?>

<?php $__env->startSection('title', 'Listado de Lentes disponibles'); ?>

<?php $__env->startSection('header'); ?>
    <h1>Listado de Lentes</h1>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <ul>
        <li><a href="<?php echo e(action([lentes_controller::class,'create'])); ?>">Agregar Nuevo</a></li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<table class="min-w-full table-auto">
    <caption>Listado de Lentes</caption>
    <thead class="justify-between">
        <tr class="bg-gray-800">
            <th class="px-16 py-2"> <span class="text-gray-300">id</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Nombre</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Precio</span>
            </th>
			<th class="px-16 py-2"> <span class="text-gray-300">Marca</span>
			</th>
            <th class="px-16 py-2"> <span class="text-gray-300">Creado</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Actualizado</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Ver</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Borrar</span>
            </th>
        </tr>
    </thead>
    <tbody class="bg-gray-200">
    <?php $__empty_1 = true; $__currentLoopData = $lentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lentes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr class="bg-white border-4 border-gray-200">
            <td class="px-16 py-2 flex flex-row items-center"><?php echo e($lentes->idLentes); ?></td>
            <td><?php echo e($lentes->nameLentes); ?></td>
            <td><?php echo e($lentes->precio); ?></td>
			<td><?php echo e($lentes->marca); ?></td>
            <td><?php echo e($lentes->created_at); ?></td>
            <td><?php echo e($lentes->updated_at); ?> fecha</td>
            <td><a href="<?php echo e(action([lentes_controller::class,'show'],['id'=>$lentes->idLentes])); ?>">VER</a></td>
            <td><a href="<?php echo e(action([lentes_controller::class,'destroy'],['id'=>$lentes->idLentes])); ?>">DEL</a></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td>No data</td>
        </tr>
    <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
    <p><?php echo e(date('Y')); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TercerParcial\resources\views/lentes/inicio.blade.php ENDPATH**/ ?>