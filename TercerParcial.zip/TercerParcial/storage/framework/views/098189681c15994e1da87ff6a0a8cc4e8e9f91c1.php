<?php use App\Http\Controllers\lentes_controller;
?>
<?php if(isset($lentes) && is_object($lentes)): ?>
    <?php
        $nameLentes = $lentes->nameLentes;
        $precio = $lentes->precio;
        $marca = $lentes->marca;
        $created_at = $lentes->created_at;
        $updated_at = $lentes->updated_at;
        $id = $lentes->idLentes;
    ?>
<?php else: ?>
    <?php
        $nameLentes = "";
        $precio = "";
        $marca = "";
        $created_at = "";
        $updated_at = "";
        $id = ""
    ?>
<?php endif; ?>

<?php $__env->startSection('title', 'Detalle de Lentes'); ?>

<?php $__env->startSection('header'); ?>
    <h1>Detalle de Lentes</h1>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
    <ul>
        <li><a href="<?php echo e(action([lentes_controller::class,'create'])); ?>">Agregar Nuevo</a></li>
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form class="w-full max-w-sm" action="<?php echo e(isset($lentes) ? action([lentes_controller::class,'update']) : action([lentes_controller::class,'store'])); ?>" method="post">
        <div class="md:flex md:items-center mb-6">
            <div class="md:w-1/3">
                <?php echo e(csrf_field()); ?>

        <input type="hidden" name="id" value="<?php echo e($id); ?>">
        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for = "nombre">Nombre</label>
            </div>
            <div class="md:w-2/3">
                <input class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500" type = "text" name = "nombre" value="<?php echo e($nameLentes); ?>"/>
            </div>
        </div>
        <div class="md:flex md:items-center mb-6">
            <div class="md:w-1/3">

        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for = "precio">Precio</label>
            </div>
            <div class="md:w-2/3">
                <input class="md:w-2/3" type = "text" name = "precio" value="<?php echo e($precio); ?>"/>
            </div>
        </div>
        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for = "marca">Marca</label>
            </div>
            <div class="md:w-2/3">
                <input class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500" type = "text" name = "marca" value="<?php echo e($marca); ?>"/>
            </div>
        </div>
        <div class="md:flex md:items-center mb-6">
            <div class="md:w-1/3">
        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for = "creado">Creado</label>
            </div>
            <div class="md:w-2/3">
                <input class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500" type = "text" name="creado" value="<?php echo e($created_at); ?>"/>
            </div>
        </div>
        <div class="md:flex md:items-center mb-6">
            <div class="md:w-1/3">
        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4"  for = "actualizado">Actualizado</label>
            </div>
            <div class="md:w-2/3">
                <input class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500" type = "text" name="actualizado" value="<?php echo e($updated_at); ?>"/>
            </div>
        </div>
                <div class="md:flex md:items-center">
                <div class="md:w-1/3"></div>
                <div class="md:w-2/3">
        <input class="shadow bg-purple-500 hover:bg-purple-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" type = "submit" value = "<?php echo e(isset($lentes) ? 'Actualizar' : 'Enviar'); ?>">
            </div>
            </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('footer'); ?>
    <p><?php echo e(date('Y')); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\TercerParcial\resources\views/Lentes/detalle.blade.php ENDPATH**/ ?>