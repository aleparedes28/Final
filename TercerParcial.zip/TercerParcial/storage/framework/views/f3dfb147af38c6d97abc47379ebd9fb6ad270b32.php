<footer>
    <?php $__env->startSection('footer'); ?>
        el pie de pagina
    <?php echo $__env->yieldSection(); ?>
</footer>
</body>
</html><?php /**PATH C:\laragon\www\TercerParcial\resources\views/includes/footer.blade.php ENDPATH**/ ?>