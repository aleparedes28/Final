<nav class="flex-1">
    <?php $__env->startSection('navbar'); ?>
        <li>
            tenemos navegacion
        </li>
    <?php echo $__env->yieldSection(); ?>
</nav><?php /**PATH C:\laragon\www\TercerParcial\resources\views/includes/nav.blade.php ENDPATH**/ ?>