<div class="p-6 max-w-sm mx-auto bg-white rounded-xl shadow-md flex items-center space-x-4">
    <?php echo $__env->yieldContent('content'); ?>
</div><?php /**PATH C:\laragon\www\TercerParcial\resources\views/includes/content.blade.php ENDPATH**/ ?>