<footer>
    @section('footer')
        el pie de pagina
    @show
</footer>
</body>
</html>