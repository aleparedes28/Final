<nav class="flex-1">
    @section('navbar')
        <li>
            tenemos navegacion
        </li>
    @show
</nav>