
@include('includes.header')

@include('includes.content')

@include('includes.footer')
