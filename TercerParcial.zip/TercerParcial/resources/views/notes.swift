public func login (Request $request){
    $user=$request
}
@selection()

{{action ([PruebasController::class, 'login'])}}