<?php use App\Http\Controllers\lentes_controller;
?>
@if(isset($lentes) && is_object($lentes))
    <?php
        $nameLentes = $lentes->nameLentes;
        $precio = $lentes->precio;
        $marca = $lentes->marca;
        $created_at = $lentes->created_at;
        $updated_at = $lentes->updated_at;
        $id = $lentes->idLentes;
    ?>
@else
    <?php
        $nameLentes = "";
        $precio = "";
        $marca = "";
        $created_at = "";
        $updated_at = "";
        $id = ""
    ?>
@endif
@extends('layouts.master')
@section('title', 'Detalle de Lentes')
{{-- Personalizo el header --}}
@section('header')
    <h1>Detalle de Lentes</h1>
    @parent
@stop
{{-- Personalizo el Navbar --}}
@section('navbar')
    <ul>
        <li><a href="{{action([lentes_controller::class,'create'])}}">Agregar Nuevo</a></li>
    </ul>
@stop
{{-- Personalizo el Contenido --}}
@section('content')
    <form class="w-full max-w-sm" action="{{isset($lentes) ? action([lentes_controller::class,'update']) : action([lentes_controller::class,'store'])}}" method="post">
        <div class="md:flex md:items-center mb-6">
            <div class="md:w-1/3">
                {{csrf_field()}}
        <input type="hidden" name="id" value="{{$id}}">
        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for = "nombre">Nombre</label>
            </div>
            <div class="md:w-2/3">
                <input class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500" type = "text" name = "nombre" value="{{$nameLentes}}"/>
            </div>
        </div>
        <div class="md:flex md:items-center mb-6">
            <div class="md:w-1/3">

        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for = "precio">Precio</label>
            </div>
            <div class="md:w-2/3">
                <input class="md:w-2/3" type = "text" name = "precio" value="{{$precio}}"/>
            </div>
        </div>
        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for = "marca">Marca</label>
            </div>
            <div class="md:w-2/3">
                <input class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500" type = "text" name = "marca" value="{{$marca}}"/>
            </div>
        </div>
        <div class="md:flex md:items-center mb-6">
            <div class="md:w-1/3">
        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4" for = "creado">Creado</label>
            </div>
            <div class="md:w-2/3">
                <input class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500" type = "text" name="creado" value="{{$created_at}}"/>
            </div>
        </div>
        <div class="md:flex md:items-center mb-6">
            <div class="md:w-1/3">
        <label class="block text-gray-500 font-bold md:text-right mb-1 md:mb-0 pr-4"  for = "actualizado">Actualizado</label>
            </div>
            <div class="md:w-2/3">
                <input class="bg-gray-200 appearance-none border-2 border-gray-200 rounded w-full py-2 px-4 text-gray-700 leading-tight focus:outline-none focus:bg-white focus:border-purple-500" type = "text" name="actualizado" value="{{$updated_at}}"/>
            </div>
        </div>
                <div class="md:flex md:items-center">
                <div class="md:w-1/3"></div>
                <div class="md:w-2/3">
        <input class="shadow bg-purple-500 hover:bg-purple-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded" type = "submit" value = "{{isset($lentes) ? 'Actualizar' : 'Enviar'}}">
            </div>
            </div>
    </form>
@stop
{{-- Personalizo el Contenido --}}
@section('footer')
    @parent
    <p>{{date('Y')}}</p>
@stop