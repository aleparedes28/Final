<?php use App\Http\Controllers\lentes_controller;?>
@extends('layouts.master')
@section('title', 'Listado de Lentes disponibles')
{{-- Personalizo el header --}}
@section('header')
    <h1>Listado de Lentes</h1>
    @parent
@stop
{{-- Personalizo el Navbar --}}
@section('navbar')
    <ul>
        <li><a href="{{action([lentes_controller::class,'create'])}}">Agregar Nuevo</a></li>
    </ul>
@stop
{{-- Personalizo el Contenido --}}
@section('content')
<table class="min-w-full table-auto">
    <caption>Listado de Lentes</caption>
    <thead class="justify-between">
        <tr class="bg-gray-800">
            <th class="px-16 py-2"> <span class="text-gray-300">id</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Nombre</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Precio</span>
            </th>
			<th class="px-16 py-2"> <span class="text-gray-300">Marca</span>
			</th>
            <th class="px-16 py-2"> <span class="text-gray-300">Creado</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Actualizado</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Ver</span>
            </th>
            <th class="px-16 py-2"> <span class="text-gray-300">Borrar</span>
            </th>
        </tr>
    </thead>
    <tbody class="bg-gray-200">
    @forelse($lentes as $lentes)
        <tr class="bg-white border-4 border-gray-200">
            <td class="px-16 py-2 flex flex-row items-center">{{$lentes->idLentes}}</td>
            <td>{{$lentes->nameLentes}}</td>
            <td>{{$lentes->precio}}</td>
			<td>{{$lentes->marca}}</td>
            <td>{{$lentes->created_at}}</td>
            <td>{{$lentes->updated_at}} fecha</td>
            <td><a href="{{action([lentes_controller::class,'show'],['id'=>$lentes->idLentes])}}">VER</a></td>
            <td><a href="{{action([lentes_controller::class,'destroy'],['id'=>$lentes->idLentes])}}">DEL</a></td>
        </tr>
    @empty
        <tr>
            <td>No data</td>
        </tr>
    @endforelse
    </tbody>
</table>
@stop
{{-- Personalizo el Contenido --}}
@section('footer')
    @parent
    <p>{{date('Y')}}</p>
@stop