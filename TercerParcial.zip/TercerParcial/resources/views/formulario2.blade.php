<!DOCTYPE html>
<html>
<head>
	<title>Formulario 2 </title>
</head>
<body>
	<h1> Formulario 2</h1>

</body>
</html>

<form method="post" action="">
	<ul>
		<li> <label for="name"> Nombre </label>
		<input type="text" id="name" name="name" /></li>
		<li><label for="lastname"> Apellido </label>
		<input type="text" id="lastname" name="lastname" /></li><li>
		<label for="age"> Edad </label>
		<input type="text" id="age" name="age" /> </li>
		<input type="submit" value="Enviar" />
	</ul>
</form>