<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\lentes_controller;
use App\Http\Controllers\PruebasController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/ale', function () {
    return view('Lentes/inicio');
});

Route::get('/yolo', function () {
    return view('welcome',  ["nombre"=>'Ale']);
});

Route:: get ('lol', function(){
    return view ('welcome')
    ->with ('nombre', 'Arturo');
});

Route:: get ('jaja/{valor}', function ($algo){
    return view ('welcome', ["nombre"=> $algo]);
});

Route:: get ('haha/{valor?}', function ($algo = 'Valor por defecto'){
    return view ('welcome', ["nombre"=> $algo]);
});

Route:: get ('haha/{valor}/{otro}/{unomas}', function ($algo, $otro, $unomas="su valor"){
    return view ('welcome', ["nombre"=> $algo]);
});

Route:: get ('a', [PruebasController::class, 'pagina']);
Route:: post('login', [PruebasController::class, 'pagina']);

Route::get('/lentes',[lentes_controller::class,'index']);
Route::get('/lentes/nuevo',[lentes_controller::class, 'create']);
Route::post('/lentes/save',[lentes_controller::class, 'store']);
Route::get('/lentes/show/{id}',[lentes_controller::class, 'show']);
Route::post('/lentes/update',[lentes_controller::class, 'update']);
Route::get('/lentes/del/{id}',[lentes_controller::class, 'destroy']);
