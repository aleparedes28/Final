<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLentes extends Migration
{
    public function up()
    {
        if (Schema::hasTable('lentes')){
        Schema::table('lentes', function (Blueprint $table) {
            if (!Schema::hasColumn('idLentes'))
            {
                $table->increments('idLentes');
            }
            if (!Schema::hasColumn('nameLentes'))
            {
                $table->string('nameLentes', 255);
            }
            if (!Schema::hasColumn('precio'))
            {
                $table->float('precio');
            }
            if (!Schema::hasColumn('color'))
            {
                $table->string('color');
            }
            if (!Schema::hasColumn('marca'))
            {
                $table->string('marca');
            }      
        });
    } else {
        Schema::create('lentes', function (Blueprint $table) {
            $table->increments('idLentes');
            $table->string('nameLentes', 255);
            $table->float('precio');
            $table->string('marca');
            $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (Schema::hasTable('lentes')) {
            Schema::table('lentes', function (Blueprint $table) {
                Schema::drop('lentes');
            });
        }
    }
}
