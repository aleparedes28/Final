<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class lentes_controller extends Controller
{
    public function index()
    {
        /*Equivale a un SELECT **/
        $lentes = DB::table('lentes')
            ->orderBy('nameLentes','asc')
            ->get();

        return view('lentes.inicio',[
            'lentes'=>$lentes]);
    }

    public function create()
    {
        return view('lentes.detalle');
    }

    public function store(Request $request)
    {
        // Equivale a un INSERT
        $lentes = DB::table('lentes')->insert([
            'nameLentes' => $request->input('nombre'),
            'precio' => $request->input('precio'),
            'marca' => $request->input('marca'),
            'created_at' => $request->input('creado'),
            'updated_at' => $request->input('actualizado')
        ]);
        return redirect()->action([lentes_controller::class, 'index']);
    }

    public function show($id)
    {
        $lentes = DB::table('lentes')
            ->where('idLentes','=',$id)
            ->first();

        return view('lentes.detalle',['lentes' => $lentes]);
    }

    public function update(Request $request)
    {
        $lentes = DB::table('lentes')
            ->where('idLentes','=',$request->input('id'))
            ->update([
            'nameLentes' => $request->input('nombre'),
            'precio' => $request->input('precio'),
            'marca' => $request->input('marca'),
            'created_at' => $request->input('creado'),
            'updated_at' => $request->input('actualizado')
        ]);
        return redirect()->action([lentes_controller::class, 'index']);
    }


    public function destroy($id)
    {
        $lentes = DB::table('lentes')
            ->where('idLentes','=',$id)
            ->delete();
        return redirect()->action([lentes_controller::class, 'index']);
    }
}